package com.ecommerce;

public class FakeOrderDetection{

    public boolean isSuspicious(){

    }
}